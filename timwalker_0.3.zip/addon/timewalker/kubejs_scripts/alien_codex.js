global.alienevo_alien_123 = ['timewalker:chronian']
global.alienevo_alien_143 = ['timewalker:chronosapien']